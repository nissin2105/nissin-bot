const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do nissin:*

➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*

╔════════════════════
  TRADUZIDO POR *NISSIN*
  DUVIDAS? 👇
  WA.me/556182025077
╚════════════════════`
}

exports.darkmenu = darkmenu









