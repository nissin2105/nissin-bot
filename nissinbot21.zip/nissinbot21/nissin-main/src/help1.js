const help1 = (prefix) => {

	return `
╭─────────────────╮
 *COMANDOS DO NISSIN*
╰─────────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}loli1*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}meme*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}marcar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*NISSIN BOT*
════════════════════`

}
exports.help1 = help1


