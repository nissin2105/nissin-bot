const help1 = (prefix) => {

	return `
╭─────────────────╮
 *COMANDOS DO NISSIN*
╰─────────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}loli1*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}meme*
➸ *${prefix}limpar*
➸ *${prefix}marcar*

════════════════════
*NISSIN BOT*
════════════════════`

}
exports.help1 = help1




